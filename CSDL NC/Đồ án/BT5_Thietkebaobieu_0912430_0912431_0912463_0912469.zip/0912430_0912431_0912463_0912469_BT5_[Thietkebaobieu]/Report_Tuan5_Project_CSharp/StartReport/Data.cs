﻿namespace StartReport {
    
    
    public partial class Data {
    }
}
namespace StartReport {
    
    
    public partial class Data {
    }
}
