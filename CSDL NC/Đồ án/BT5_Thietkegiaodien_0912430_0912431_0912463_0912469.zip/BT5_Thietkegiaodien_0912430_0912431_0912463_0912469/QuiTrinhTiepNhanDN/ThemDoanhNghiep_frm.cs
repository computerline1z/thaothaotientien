﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuiTrinhTiepNhanDN
{
    public partial class ThemDoanhNghiep_frm : Form
    {
        public ThemDoanhNghiep_frm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Đã thêm doanh nghiệp thành công, bạn có muốn nhập sản phẩm không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            Themsanpham_frm frm = new Themsanpham_frm();
            frm.ShowDialog();
            Close();
        }
    }
}
